//
//  QuizQuestionAnswerVerticallyVC.swift
//  btutee
//
//  Created by apple on 17/10/19.
//  Copyright © 2019 Sumit Sharma. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import MBProgressHUD

@available(iOS 13.0, *)
class QuizQuestionAnswerVerticallyVC: UIViewController
{
    @IBOutlet var viewCollection: UIView!
    @IBOutlet weak var collView: UICollectionView!
    @IBOutlet var btnPrevious: UIButton!
    @IBOutlet var btnNext: UIButton!
    @IBOutlet var lblBottomCountBar: UILabel!
    
    let userDefaults = UserDefaults.standard
    @IBOutlet var btnSubmit: UIButton!
    
    var intCounterCheckImage = Int()
    var arrIndexcounter = [Int]()
    var indexOfLastQuestion = Int()
    
    var arrQuizDataMakeJsonResponse:NSMutableArray = []
    
    
    var getdict : [String: Any] = [:]
    var responseDictionary:[String:Any] = [:]
    var arrQuestionAnswerListing:[[String:Any]] = [[:]]
    
    
    @IBOutlet weak var navigationBar:UIView! {
        didSet {
            navigationBar.backgroundColor = NAVIGATION_COLOR
        }
    }
    
    @IBOutlet weak var lblNavigationTitle:UILabel! {
        didSet {
            lblNavigationTitle.text = "LEVEL 1"
            lblNavigationTitle.textColor = NAVIGATION_TITLE_COLOR
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
        //        TAUtility.roundedButtonWithColour(btn: btnSubmit, colr: .white, bgcolour: .clear)
        callGetAllQuizQuestionList()
        NotificationCenter.default.addObserver(self, selector: #selector(self.showSpinningWheel(_:)), name: NSNotification.Name(rawValue: "notificationName"), object: nil)
    }
    
//    @IBAction func btnLeftArrowAction(_ sender: Any)
//    {
//        let collectionBounds = collView.bounds
//        let contentOffset = CGFloat(floor(collView.contentOffset.x - collectionBounds.size.width ))
//        self.moveCollectionToFrame(contentOffset: contentOffset)
//    }
    
    @IBAction func btnRightArrowAction(_ sender: Any)
    {
        let collectionBounds = collView.bounds
        let contentOffset = CGFloat(floor(collView.contentOffset.x + collectionBounds.size.width ))
        self.moveCollectionToFrame(contentOffset: contentOffset)
    }
    
    func moveCollectionToFrame(contentOffset : CGFloat)
    {
        let frame: CGRect = CGRect(x : contentOffset ,y : collView.contentOffset.y ,width : collView.frame.width,height : collView.frame.height)
        collView.scrollRectToVisible(frame, animated: true)
    }
    
    // ========Login Array Make Selectable Option Answer===========//
    @objc func showSpinningWheel(_ notification: NSNotification)
    {
        if let dict = notification.userInfo as NSDictionary?
        {
            // quiz_question_id
            let get_Question_Id = dict["quiz_question_id"] as! String
            let existingArrayElement = self.arrQuizDataMakeJsonResponse as! [[String:Any]]
            for index in 0..<existingArrayElement.count
            {
                let dict = existingArrayElement[index]
                if(get_Question_Id == dict["quiz_question_id"] as! String)
                {
                    self.arrQuizDataMakeJsonResponse.removeObject(at: index)
                }
            }
            self.arrQuizDataMakeJsonResponse.insert(dict, at: self.arrQuizDataMakeJsonResponse.count)
        }
    }
    
    
    @IBAction func btnSubmitClickMe(_ sender: Any)
    {
        let total_count = self.arrQuestionAnswerListing.count
        print(total_count as Int) // 40
        
        let attemptAnswerCount = self.arrQuizDataMakeJsonResponse.count
        print(attemptAnswerCount as Int)
        
        let remainingQuestionCount =  total_count - attemptAnswerCount
        print(remainingQuestionCount as Int)
        for indexNext in attemptAnswerCount..<total_count
        {
            let dictQuizDataMakeJsonResponse:NSMutableDictionary = NSMutableDictionary()
            dictQuizDataMakeJsonResponse.setValue("0", forKey: "quiz_question_id")
            dictQuizDataMakeJsonResponse.setValue("0", forKey: "quiz_answer_id")
            self.arrQuizDataMakeJsonResponse.insert(dictQuizDataMakeJsonResponse, at: indexNext)
        }
        print("All Answer Attempt Array ::=>>  \(self.arrQuizDataMakeJsonResponse.count)")
        
        //        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ExamResultVC") as? ExamResultVC
        //        userDefaults.set(01, forKey: "nextTag")
        //        self.navigationController?.pushViewController(vc!, animated: false)
    }
    
    func alertviewCommonFunc(message1: String?)
    {
        //        let alert : UIAlertView = UIAlertView(title:Localization("alert_txt"), message: message1, delegate: nil, cancelButtonTitle: Localization("ok_txt"))
        //        alert.show()
    }
    
func callGetAllQuizQuestionList() {
    if isInternetAvailable() == false{
        let alert = UIAlertController(title: "Alert", message: "Device is not connected to Internet", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    else{
//        let dict : [String : Any] = UserDefaults.standard.dictionary(forKey: "kAPI_LOGIN_DATA") ?? [:]
        let spinnerActivity = MBProgressHUD.showAdded(to:view, animated: true);
        spinnerActivity.label.text = "Loading";
        spinnerActivity.detailsLabel.text = "Please Wait!!";
        
        if let apiString = URL(string:BaseUrl) {
            var request = URLRequest(url:apiString)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            let values = ["action":"quizlist","type": "2"]as [String : Any]as [String : Any]
            print("Values \(values)")
            request.httpBody = try! JSONSerialization.data(withJSONObject: values)
            AF.request(request)
                .responseJSON { response in
                    // do whatever you want here
                    MBProgressHUD.hide(for:self.view, animated: true)
                    switch response.result {
                    case .failure(let error):
                        let alertController = UIAlertController(title: "Alert", message: "Some error Occured", preferredStyle: .alert)
                        let okAction = UIAlertAction(title: "Ok", style: .cancel) { (action:UIAlertAction!) in
                            print("you have pressed the Ok button");
                        }
                        alertController.addAction(okAction)
                        self.present(alertController, animated: true, completion:nil)
                        print(error)
                        if let data = response.data,
                           let responseString = String(data: data, encoding: .utf8) {
                            print(responseString)
                            print("response \(responseString)")
                        }
                    case .success(let responseObject):
                        DispatchQueue.main.async {
                            print("This is run on the main queue, after the previous code in outer block")
                        }
                        print("response \(responseObject)")
                        MBProgressHUD.hide(for:self.view, animated: true)
                        if let dict = responseObject as? [String:Any] {
                            self.arrQuestionAnswerListing = dict["data"] as? [[String : Any]] ?? [[:]]
                            print(self.arrQuestionAnswerListing)
                            if(self.arrQuestionAnswerListing.count != 0){
                                self.collView.isHidden = false
                                self.collView.reloadData()
                            }else{
                                self.collView.isHidden = true
                            }
                        }
                    }
                }
            }
        }
    }
}

class tblAnswerCell: UITableViewCell
{
    @IBOutlet weak var lblAnswer: UILabel!
    @IBOutlet weak var imgAnswerBG: UIImageView!
    @IBOutlet weak var imgAnswer: UIImageView!
    @IBOutlet var imgAnswerHeightConstant: NSLayoutConstraint!
}

class AssignmentCollectionCell: UICollectionViewCell
{
    @IBOutlet var viewCell: UIView!
    @IBOutlet var viewInner: UIView!
    @IBOutlet var lblQuestion: UILabel!
    @IBOutlet var imgQuestion: UIImageView!
    @IBOutlet var imgQuestionHeightConstant: NSLayoutConstraint!
    
    @IBOutlet weak var tableView: UITableView!
    var arrJSON:[[String:Any]] = [[:]]
    var question_id  = Int()
    @IBOutlet weak var imgAnswerBG: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        self.tableView.delegate = self
        self.tableView.dataSource = self
    }
}



@available(iOS 13.0, *)
extension QuizQuestionAnswerVerticallyVC : UICollectionViewDataSource , UICollectionViewDelegateFlowLayout , UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width  = ( viewCollection.frame.width )
        let height  = ( viewCollection.frame.height - 40 )
        return CGSize(width: width, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        let total_count = self.arrQuestionAnswerListing.count
        self.lblBottomCountBar.text = "\(indexPath.row + 1) / \(total_count)"
        indexOfLastQuestion = indexPath.row + 1
        
        if(indexPath.row + 1 == 1) {
            btnPrevious.isHidden = true
        } else {
            btnPrevious.isHidden = false
        }
        
        if(indexPath.row + 1 == total_count) {
            btnNext.isHidden = true
        } else {
            btnNext.isHidden = false
        }
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if(indexOfLastQuestion == 1) {
            btnPrevious.isHidden = true
        } else {
            btnPrevious.isHidden = false
        }
        
        let total_count = self.arrQuestionAnswerListing.count
        if(indexOfLastQuestion == total_count) {
            btnNext.isHidden = true
        } else {
            btnNext.isHidden = false
        }
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return  arrQuestionAnswerListing.count //arrJSON.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AssignmentCollectionCell", for: indexPath) as! AssignmentCollectionCell
//        TAUtility.roundedCornerBorderView(view: cell.viewInner)
        
        let dictCollection:[String:Any] = self.arrQuestionAnswerListing[indexPath.row]
        cell.lblQuestion.text = "\(dictCollection["question"] as? String ?? "")"
        
//        let strImageQuestionUrl = dictCollection["quiz_image"]
//        if(TAUtility.validString(string: strImageQuestionUrl) != "") {
//            cell.imgQuestionHeightConstant.constant = 150
//            cell.imgQuestion.dowloadFromServer(link: ( dictCollection["quiz_image"] as? String ?? "" ), contentMode: .scaleToFill)
//        } else {
//            cell.imgQuestionHeightConstant.constant = 0
//            cell.imgQuestion.image = UIImage(named: "")
//        }
        cell.arrJSON.removeAll()
        cell.arrJSON = dictCollection["option"] as? [[String:Any]] ?? [[:]]
        cell.question_id = dictCollection["answer"] as? Int ?? 0
        cell.tableView.reloadData()
        
        return cell
    }
}

extension AssignmentCollectionCell: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrJSON.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:tblAnswerCell = (tableView.dequeueReusableCell(withIdentifier: "tblAnswerCell") as? tblAnswerCell)!
        let dictTbl:[String:Any] = self.arrJSON[indexPath.row]
        cell.lblAnswer.text = dictTbl["value"] as? String
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell:tblAnswerCell = (tableView.cellForRow(at: indexPath) as? tblAnswerCell)!
        cell.imgAnswerBG.image = UIImage(named: "check3")
//        let dictTbl:[String:Any] = self.arrJSON[indexPath.row] as![String:Any]
//        let dictQuizDataMakeJsonResponse:NSMutableDictionary = NSMutableDictionary()
//        dictQuizDataMakeJsonResponse.setValue(dictTbl["quiz_question_id"] as? String ?? "", forKey: "quiz_question_id")
//        dictQuizDataMakeJsonResponse.setValue(dictTbl["quiz_answer_id"] as? String ?? "", forKey: "quiz_answer_id")
//        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "notificationName"), object: nil, userInfo: dictQuizDataMakeJsonResponse as? [AnyHashable : Any])
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        let cell:tblAnswerCell = (tableView.cellForRow(at: indexPath) as? tblAnswerCell)!
        cell.imgAnswerBG.image = UIImage(named: "check5")
        let dictTbl:[String:Any] = self.arrJSON[indexPath.row]
        print(dictTbl as Any)
        print("IMG DESELECTED")
    }
}
