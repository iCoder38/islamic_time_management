//
//  EvaluateSuccess.swift
//  IslamicTimeManagement
//
//  Created by Apple on 09/03/21.
//

import UIKit
import Alamofire
import SwiftyJSON
import MBProgressHUD
import Charts


class EvaluateSuccess: UIViewController, ChartViewDelegate {
    var responseDictionary:[String:Any] = [:]
    var responseArray:[[String:Any]] = [[:]]
    
//    @IBOutlet weak var barChartView: BarChartView!
//    var months: [String]!
//
    @IBOutlet weak var barChartView: BarChartView!
    weak var axisFormatDelegate: IAxisValueFormatter?
    var months: [String]!
    var unitsSold = [Double]()

    @IBOutlet weak var navigationBar:UIView! {
        didSet {
            navigationBar.backgroundColor = NAVIGATION_COLOR
        }
    }
    
    @IBOutlet weak var lblNavigationTitle:UILabel! {
        didSet {
            lblNavigationTitle.text = "EVALUATE"
            lblNavigationTitle.textColor = NAVIGATION_TITLE_COLOR
        }
    }
    
    @IBOutlet weak var btnMenu:UIButton! {
        didSet {
            btnMenu.tintColor = .white
        }
    }
    
    @IBOutlet weak var lblTotal:UILabel!
    
    override func viewDidLoad(){
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        let getCount = UserDefaults.standard.string(forKey: "totalValue")
        self.lblTotal.text = getCount        
        self.sideBarMenuClick()
        EvaluationHistoryData()
        
        barChartView.delegate = self
        months  = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        unitsSold  = [20.0, 54.0, 6.0, 30.0, 92.0, 16.0,114.0]
        setChart(dataPoints: months, values: unitsSold)
    }
        
    func setChart(dataPoints: [String], values: [Double]) {
        guard dataPoints.count > 0 else { return }
        var dataEntries = [BarChartDataEntry]()
        for i in 0..<dataPoints.count {
            let entry = BarChartDataEntry(x: Double(i), y: values[i], data: months as AnyObject?)
            dataEntries.append(entry)
        }

        let chartDataSet = BarChartDataSet(entries: dataEntries, label: "Units Sold")
        let chartData = BarChartData(dataSet: chartDataSet)
        barChartView.data = chartData
        chartDataSet.colors = [UIColor(red: 230/255, green: 126/255, blue: 34/255, alpha: 1)]
        chartDataSet.colors = [UIColor(red: 23/255, green: 12/255, blue: 39/255, alpha: 1)]

        chartDataSet.colors = ChartColorTemplates.colorful()
        barChartView.xAxis.labelPosition = .bottom

        let l = barChartView.legend
        l.horizontalAlignment = .left
        l.verticalAlignment = .bottom
        l.orientation = .horizontal
        //l.drawInside = false
        l.form = .circle
        l.formSize = 9
        l.font = UIFont(name: "HelveticaNeue-Light", size: 11)!
        l.xEntrySpace = 4

    }
    
    func chartValueSelected(chartView: ChartViewBase, entry: ChartDataEntry, dataSetIndex: Int, highlight: Highlight) {
//        print("\(entry.value) in \(months[entry.xIndex])")
    }
    
//    @IBAction func saveChart(sender: UIBarButtonItem) {
//        barChartView.saveToCameraRoll()
//    }

    @objc func sideBarMenuClick() {
        let defaults = UserDefaults.standard
        defaults.setValue("", forKey: "keyBackOrSlide")
        defaults.setValue(nil, forKey: "keyBackOrSlide")
        if revealViewController() != nil {
            btnMenu.addTarget(self.revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:)), for: .touchUpInside)
            revealViewController().rearViewRevealWidth = 300
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
    }
    
    func EvaluationHistoryData(){
        if isInternetAvailable() == false{
            let alert = UIAlertController(title: "Alert", message: "Device is not connected to Internet", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else{
            let spinnerActivity = MBProgressHUD.showAdded(to:view, animated: true);
            spinnerActivity.label.text = "Loading";
            spinnerActivity.detailsLabel.text = "Please Wait!!"
            
            let dict : [String : Any] = UserDefaults.standard.dictionary(forKey: "kAPI_LOGIN_DATA") ?? [:]
            if let apiString = URL(string:BaseUrl) {
                var request = URLRequest(url:apiString)
                request.httpMethod = "POST"
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                let date = Date()
                let formate = date.getFormattedDate(format: "yyyy-MM-dd")
                var myDate = Date()
                myDate.changeDays(by: -7)
                let formate1 = myDate.getFormattedDate(format: "yyyy-MM-dd")
                let values = ["action":"evalutionhistory","userId":String(dict["userId"]as? Int ?? 0),"pageNo":"","startDate":formate1,"endDate":formate]
                print("Values \(values)")
                
                request.httpBody = try! JSONSerialization.data(withJSONObject: values)
                AF.request(request)
                    .responseJSON { response in
                        MBProgressHUD.hide(for:self.view, animated: true)
                        switch response.result {
                        case .failure(let error):
                            let alertController = UIAlertController(title: "Alert", message: "Some error Occured", preferredStyle: .alert)
                            let okAction = UIAlertAction(title: "Ok", style: .cancel) { (action:UIAlertAction!) in
                                print("you have pressed the Ok button");
                            }
                            alertController.addAction(okAction)
                            self.present(alertController, animated: true, completion:nil)
                            print(error)
                            if let data = response.data,
                               let responseString = String(data: data, encoding: .utf8) {
                                print(responseString)
                                print("response \(responseString)")
                            }
                        case .success(let responseObject):
                            DispatchQueue.main.async {
                                print("This is run on the main queue, after the previous code in outer block")
                            }
                            print("response \(responseObject)")
                            MBProgressHUD.hide(for:self.view, animated: true)
                            if let dict = responseObject as? [String:Any] {
                                self.responseArray = dict["data"] as? [[String : Any]] ?? [[:]]
                                if(self.responseArray.count != 0){
//                                    let dataEntries = self.generateEmptyDataEntries()
//                                    self.basicBarChart.updateDataEntries(dataEntries: dataEntries, animated: false)
//                                    let timer = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: false) {[unowned self] (timer) in
//                                        let dataEntries = self.generateRandomDataEntries()
//                                        self.basicBarChart.updateDataEntries(dataEntries: dataEntries, animated: false)
//                                    }
//                                    timer.fire()
                                }else{
                                }
                            }
                        }
                    }
            }
        }
    }
    
    @IBAction func checkButtonTapped(_ sender: Any) {
        let push = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "EvaluateSuccessMonthlyWiseVCid")
        self.navigationController?.pushViewController(push, animated: true)
    }

//    
//    func generateEmptyDataEntries() -> [DataEntry] {
//        var result: [DataEntry] = []
//        Array(0..<self.responseArray.count).forEach {_ in
//            result.append(DataEntry(color: UIColor.clear, height: 0, textValue: "0", title: ""))
//        }
//        return result
//    }
    
//    var arrGetValue:[[String:Any]] = [[:]]
//    func generateRandomDataEntries() -> [DataEntry] {
//        let colors = [#colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1), #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1), #colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1), #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1), #colorLiteral(red: 0.9372549057, green: 0.3490196168, blue: 0.1921568662, alpha: 1), #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1), #colorLiteral(red: 0.3647058904, green: 0.06666667014, blue: 0.9686274529, alpha: 1)]
//        var result: [DataEntry] = []
//        for i in 0..<self.responseArray.count {
//            let dict : [String :Any] = self.responseArray[i]
//            self.arrGetValue = dict["JsonData"] as? [[String : Any]] ?? [[:]]
//            var totalValueCount = Int()
//            if(self.arrGetValue.count != 0){
//                for index in 0..<self.arrGetValue.count{
//                    let element = self.arrGetValue[index]
//                    let marks = element["marks"] as? Int ?? 0
//                    totalValueCount += marks
//                }
//            }
//            let value = totalValueCount
//            let height: Float = Float(value) / 100.0
//            result.append(DataEntry(color: colors[i % colors.count], height: height, textValue: "\(value)", title: ""))
//        }
//        return result
//    }
}

extension Date {
    func getFormattedDate(format: String) -> String {
        let dateformat = DateFormatter()
        dateformat.dateFormat = format
        return dateformat.string(from: self)
    }
}
extension Date {
    mutating func changeDays(by days: Int) {
        self = Calendar.current.date(byAdding: .day, value: days, to: self)!
    }
}
